/**
 * js/stock.js
 * จัดการข้อมูลสินค้า สต็อก SKU และ History Log
 */
import { storage } from './storage.js';
import { generateId } from './utils.js';

const CARDS_KEY = 'tcg_cards';
const LOGS_KEY = 'stock_logs';

export async function getCards() {
    return await storage.getItem(CARDS_KEY, []);
}

export async function saveCards(cards) {
    await storage.setItem(CARDS_KEY, cards);
}

/**
 * บันทึกประวัติการเปลี่ยนแปลงสต็อก (Stock Movement Log)
 */
export async function logStockMovement(cardId, cardName, type, qty, note = '') {
    const logs = await storage.getItem(LOGS_KEY, []);
    logs.unshift({
        id: generateId('LOG'),
        cardId,
        cardName,
        type, // 'ADD', 'SALE', 'RETURN', 'ADJUST'
        quantity: qty,
        note,
        timestamp: new Date().toISOString()
    });
    await storage.setItem(LOGS_KEY, logs);
}

/**
 * คำนวณ Margin %
 */
export function calculateMargin(cost, sell) {
    if (!sell || sell <= 0) return 0;
    const profit = sell - cost;
    return ((profit / sell) * 100).toFixed(2);
}